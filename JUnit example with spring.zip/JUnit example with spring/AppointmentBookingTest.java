package com.ab.leo.appointmentsynch.tests;
import com.ab.leo.appointmentsynch.data.AppointmentBookingTO;
import com.ab.leo.appointmentsynch.db.model.AppointmentBooking;
import com.ab.leo.appointmentsynch.db.repository.AppointmentBookingRepo;
import com.ab.leo.appointmentsynch.service.BookingNotificationMessageConverter;
import com.ab.leo.appointmentsynch.service.ManageDatabaseService;
import com.ab.leo.appointmentsynch.service.TransferObjectToEntityConverter;
import com.ab.tsf.eab.communication.MatchingInfo;
import com.ab.tsf.eab.communication.*;

import com.ab.leo.appointmentsynch.service.AppointmentBookingService;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Import;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.test.context.TestPropertySource;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import static org.junit.Assert.*;

@RunWith(SpringRunner.class)
@Import(AppointmentBookingMessageJUnitConfig.class)
@TestPropertySource(locations="classpath:test-application.properties")
@EnableTransactionManagement
@EnableJpaRepositories("com.ab.leo.appointmentsynch.db.repository")
public class AppointmentBookingTest {


    @Autowired
    private AppointmentBookingService appointmentBookingService;

    @Autowired
    private BookingNotificationMessageConverter bookingNotificationMessageConverter;

    @Autowired
    private TransferObjectToEntityConverter transferObjectToEntityConverter;

    @Autowired
    private ManageDatabaseService manageDatabaseService;

    @Autowired
    private AppointmentBookingRepo appointmentBookingRepo;

    @Autowired
    private ApplicationContext applicationContext;

    private static final Logger LOGGER = LoggerFactory.getLogger(AppointmentBookingTest.class);

    @Test
    public void insertAppointmentBooking() {

        appointmentBookingService.insertAppointmentBooking(prefilledBooking());

    }

    @Test
    public void readAppointmentBooking() {

        LOGGER.debug("*** CreateEmployeeIntegrationTest - read - START ***");
        List<AppointmentBooking> bookingList = appointmentBookingRepo.findAll();
        assertEquals(3,bookingList.size());
        LOGGER.debug("*** CreateEmployeeIntegrationTest - read - START ***");

    }

    @Test
    public void printContextBean() {

        LOGGER.debug("*** OneClinicalMultipleShellBatchIntegrationTest - printContextBean - START ***");
        String[] beans = applicationContext.getBeanDefinitionNames();
        LOGGER.debug("*** OneClinicalMultipleShellBatchIntegrationTest - printContextBean - number of beans: " + beans.length);
        Arrays.sort(beans);
        int id = 1;
        for (String bean : beans)
        {
            LOGGER.debug(id +") " + bean + " of Type :: " + applicationContext.getBean(bean).getClass());
            id++;
        }
        LOGGER.debug("*** OneClinicalMultipleShellBatchIntegrationTest - printContextBean -   END ***");
    }

    @Test
    public void existsByLongId(){
        Long id = Long.valueOf(2);
        Boolean found = appointmentBookingRepo.existsById(id);
        assertTrue(found);
    }


    public AppointmentBooking prefilledBooking(){

        AppointmentBookingTO appointmentBookingTO = bookingNotificationMessageConverter.convertBookingNotificationMessageTOAppointmentBooking(prefilledMessage());
        AppointmentBooking appointmentBooking = transferObjectToEntityConverter.convertToEntityAppointmentBooking(appointmentBookingTO);

        return appointmentBooking;
    }

    public BookingNotificationMessage prefilledMessage() {

        BookingNotificationMessage message = new BookingNotificationMessage();
        BookingNotificationHeader header = new BookingNotificationHeader();
        header.setCorrelationID("0001");
        header.setOperation(OperationType.CREATE_BOOKING);
        header.setTimestamp(new Date());
        header.setChannel("Channel");
        header.setBusinessArea(BusinessAreaType.OPS);
        BookingNotificationBody body = new BookingNotificationBody();
        CustomerAndBookingMessageType messageType = new CustomerAndBookingMessageType();
        Customer customer = getCustomerBase();
        MatchingInfo matchingInfo = new MatchingInfo();
        matchingInfo.setDestinationCustomerID("");
        matchingInfo.setDestinationCustomerIDType(DestinationCustomerIDType.OPS);
        matchingInfo.setMatchStatus(MatchType.CONFIRMED);
        customer.setMatchingInfo(matchingInfo);
        messageType.setCustomer(customer);
        body.setCreateBooking(messageType);
        CustomerOnlyMessageType onlyMessageType = new CustomerOnlyMessageType();
        Customer customerOnlyMessageType = getCustomerBase();
        onlyMessageType.setCustomer(customerOnlyMessageType);
        body.setAmendCustomer(onlyMessageType);
        CancelBooking cancelBooking = new CancelBooking();
        cancelBooking.setQFlowBookingID("QFLOWID0001");
        cancelBooking.setReason("");
        body.setCancelBooking(cancelBooking);
        RescheduleBooking rescheduleBooking = new RescheduleBooking();
        rescheduleBooking.setPrevQFlowBookingID("QFLOWID0002");
        rescheduleBooking.setReason("");
        rescheduleBooking.setQFlowBookingID("QFLOWID0003");
        rescheduleBooking.setBookingDate(new Date());
        rescheduleBooking.setBookingTime(new Date());
        rescheduleBooking.setBookingDuration("");
        rescheduleBooking.setClinic("");
        rescheduleBooking.setServiceType("");
        rescheduleBooking.setBookingStatus("");
        rescheduleBooking.setBookingStore("");
        rescheduleBooking.setNotes("");
        body.setRescheduleBooking(rescheduleBooking);
        Anonymise anonymise = new Anonymise();
        anonymise.setQFlowCustomerID("QFLOWID0003");
        anonymise.setQFlowBookingID("QFLOWID0003");
        anonymise.setReason("");
        body.setAnonymise(anonymise);
        message.setHeader(header);
        message.setBody(body);
        return message;
    }

    private Customer getCustomerBase() {
        Customer customer = new Customer();
        customer.setQFlowCustomerID("");
        customer.setFirstName("");
        customer.setLastName("");
        customer.setSalutation("");
        customer.setDateOfBirth("");
        customer.setPostalAddress("");
        customer.setPhoneNumber("");
        customer.setEMailAddress("");
        return customer;

    }
}
